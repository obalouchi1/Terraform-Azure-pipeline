variable "name_prefix" {
  type = string
}
variable "location" {
  type = string
}
variable "resource_group_name" {
  type = string
}
variable "vnet_address_space" {
  type = list(string)
}
variable "subnet_prefixes" {
  type = map(string)
}
variable "tags" {
  type    = map(string)
  default = {}
}
